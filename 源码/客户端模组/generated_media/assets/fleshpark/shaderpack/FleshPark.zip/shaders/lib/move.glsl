// 肉的网格：顶点色的透明度 254 是记号，颜色里存的是相位、幅度、种类。肉壁整片慢慢起伏，肉索有鼓包顺着爬
bool liquidMarked(vec4 color) {
    return abs(color.a - 0.98824) < 0.002;
}

bool fleshMarked(vec4 color) {
    return abs(color.a - 0.99608) < 0.002;
}

float fleshPush(vec4 color, vec3 w, float t) {
    if (color.b < 0.002) {
        return 0.2 * sin(w.x * 0.31 + t * 0.55 + sin(w.y * 0.23 + t * 0.31) * 1.4) * sin(w.z * 0.27 - t * 0.43 + sin(w.x * 0.19) * 1.2)
             + 0.06 * sin(w.y * 0.9 + t * 1.1) * sin(w.x * 0.7 - t * 0.6);
    }
    float wave = 0.5 + 0.5 * sin(color.r * 6.28318 - t * 1.5);
    return color.g * 0.5 * wave * wave * wave;
}

// 深井的喉咙里，肉怕手电：光斑落到的地方往里缩、发抖，光挪开就鼓回来。view 是没动过的顶点在镜头坐标里的位置。
// 只在井的喉咙那一段：井心、高度和插件 Well.java（SX=510、SZ=0、喉咙 70 到 172）对上。要先 include flash.glsl。
// 返回镜头坐标里的位移：顺着法线往里缩，再从光斑中心往四周退开（正对着照也看得出一个洞在张开），一直在抖。
vec3 fleshShy(vec3 view, vec3 normalView, vec3 world, float t) {
    if (currentPlayerHunger * 20.0 < 13.5) return vec3(0.0);
    vec2 axis = world.xz - vec2(510.5, 0.5);
    if (world.y < 64.0 || world.y > 178.0 || dot(axis, axis) > 34.0 * 34.0) return vec3(0.0);
    vec3 f = view - HAND_POS;
    float d = length(f);
    float c = -f.z / max(d, 0.001);
    float k = smoothstep(0.88, 0.992, c) * (1.0 - smoothstep(2.0, 10.0, d));
    if (k <= 0.0) return vec3(0.0);
    float shake = 0.9 + 0.14 * sin(t * 24.0 + world.x * 3.1 + world.y * 2.3 + world.z * 1.7);
    vec2 side = f.xy / max(length(f.xy), 0.001);
    // 越靠光斑中心退得越多，边上一圈挤起来
    float open = k * (1.0 - k) * 4.0 * 0.5 + k * 0.3;
    return -normalView * k * 0.9 * shake + vec3(side * open * 0.8 * shake, 0.0);
}

// 带光滑法线的模型：透明度 253 是记号，R、G 是法线，B 是这张表里的颜色序号。和模组里 Shape.TINTS 一一对应
const vec3 TINTS[39] = vec3[39](vec3(1.0), vec3(0.557, 0.565, 0.525), vec3(0.306, 0.416, 0.392), vec3(0.180, 0.196, 0.204), vec3(0.333, 0.337, 0.337), vec3(0.416, 0.329, 0.267), vec3(0.431, 0.439, 0.424), vec3(0.286, 0.396, 0.353), vec3(0.722, 0.659, 0.627), vec3(0.0), vec3(1.0, 0.984, 0.961), vec3(0.843, 0.278, 0.208), vec3(0.141, 0.129, 0.122), vec3(0.706, 0.69, 0.667), vec3(0.173, 0.478, 0.455), vec3(0.910, 0.400, 0.118), vec3(0.847, 0.855, 0.824), vec3(0.604, 0.227, 0.196), vec3(0.180, 0.227, 0.322), vec3(0.361, 0.486, 0.588), vec3(0.690, 0.541, 0.227), vec3(0.541, 0.478, 0.353), vec3(0.784, 0.769, 0.722), vec3(0.353, 0.376, 0.251), vec3(0.659, 0.439, 0.478), vec3(0.243, 0.314, 0.408), vec3(0.847, 0.831, 0.792), vec3(0.784, 0.627, 0.188), vec3(0.627, 0.557, 0.384), vec3(0.243, 0.290, 0.212), vec3(0.173, 0.204, 0.251), vec3(0.847, 0.627, 0.125), vec3(0.478, 0.290, 0.416), vec3(0.290, 0.416, 0.227), vec3(0.227, 0.165, 0.133), vec3(0.416, 0.290, 0.188), vec3(0.541, 0.518, 0.471), vec3(0.722, 0.353, 0.165), vec3(0.353, 0.227, 0.165));

bool smoothMarked(vec4 color) {
    return abs(color.a - 0.99216) < 0.002;
}

vec3 octDecode(vec2 e) {
    vec2 f = e * 2.0 - 1.0;
    vec3 n = vec3(f, 1.0 - abs(f.x) - abs(f.y));
    if (n.z < 0.0) n.xy = (1.0 - abs(n.yx)) * vec2(n.x >= 0.0 ? 1.0 : -1.0, n.y >= 0.0 ? 1.0 : -1.0);
    return normalize(n);
}
